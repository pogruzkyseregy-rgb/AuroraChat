# Аврора: приложение-чат, версия 0.2

Что нового: новый дизайн, иконка, стикеры и альбом (общие для тебя и Авроры),
отправка фото из галереи, добавление своих стикеров и фото.

## Обновление приложения
1. Загрузить этот zip в корень репозитория AuroraChat (Add file → Upload files).
2. Actions → Unpack → Run workflow.
3. Actions → Build APK → Run workflow (сам после Unpack он не запускается).
4. Скачать артефакт aurora-chat, установить.

## Обновление сервера (в Termux на телефоне)
    scp /storage/emulated/0/Download/relay.py root@92.118.112.46:/opt/aurora-relay/relay.py
    ssh root@92.118.112.46 systemctl restart aurora-relay

## Подпись (один раз)
Приватный репозиторий, файл aurora-debug.jks в папку app (имя менять не нужно),
секреты KS_PASS и KS_ALIAS (alias: aurora).
