# Аврора: приложение-чат, версия 0.5

Память в три слоя: сырая переписка (не удаляется) → эпизоды (неизменяемые пересказы)
→ ядро (язык, повороты, тон; правится точечно).

## Сервер (Termux на телефоне)
    pkg install -y unzip
    unzip -p /storage/emulated/0/Download/aurora-chat-v5b.zip aurora-relay/relay.py | ssh root@92.118.112.46 "cat > /opt/aurora-relay/relay.py && systemctl restart aurora-relay"

## Проверка сжатия на сцене «ссора, холодный фактор, возвращение»
    unzip -p /storage/emulated/0/Download/aurora-chat-v5b.zip aurora-relay/probe_memory.py | ssh root@92.118.112.46 "sleep 3; python3 -"

## Приложение
1. Загрузить zip в корень репозитория AuroraChat.
2. Actions → Unpack → Run workflow.
3. Actions → Build APK → Run workflow.
4. Установить поверх (подпись постоянная).
