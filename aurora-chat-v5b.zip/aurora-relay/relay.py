"""
Посредник между приложением «Аврора» и API.
Ключ API хранится только здесь, на сервере. Приложение знает лишь свой токен.

Эндпоинты:
  GET  /health      проверка
  POST /chat        обычный ответ Авроры
  POST /memory      сжатие старой переписки в долговременную память
  POST /initiative  Аврора решает, писать ли первой (или отвечает «ПРОПУСК»)
"""
import json
import os
from pathlib import Path

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

UPSTREAM_URL = os.environ["UPSTREAM_URL"]
UPSTREAM_KEY = os.environ["UPSTREAM_KEY"]
MODEL = os.environ.get("MODEL", "gpt-4o-mini")
APP_TOKEN = os.environ["APP_TOKEN"]
CORE_PATH = Path(os.environ.get("CORE_PATH", "/opt/aurora-relay/core.md"))
MAX_HISTORY = 40
# Сжатие памяти редкое и важное: для него можно поставить самую сильную модель провайдера
MEMORY_MODEL = os.environ.get("MEMORY_MODEL") or MODEL

app = FastAPI()


class Msg(BaseModel):
    role: str
    content: str


class Item(BaseModel):
    id: str
    desc: str = ""


class ChatReq(BaseModel):
    messages: list[Msg]
    memory: str = ""
    persona: str = ""
    stickers: list[Item] = []
    photos: list[Item] = []


class CoreItem(BaseModel):
    id: str
    kind: str = ""
    text: str = ""


class MemReq(BaseModel):
    core: list[CoreItem] = []
    messages: list[Msg]


class InitReq(BaseModel):
    messages: list[Msg]
    memory: str = ""
    persona: str = ""
    stickers: list[Item] = []
    photos: list[Item] = []
    reason: str = "share"
    gap_minutes: int = 0
    local_time: str = ""
    unanswered: int = 0


def check_auth(authorization: str) -> None:
    if authorization != f"Bearer {APP_TOKEN}":
        raise HTTPException(401, "bad token")


async def ask_model(msgs: list[dict], model: str | None = None) -> str:
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(
            UPSTREAM_URL,
            headers={"Authorization": f"Bearer {UPSTREAM_KEY}"},
            json={"model": model or MODEL, "messages": msgs},
        )
    if r.status_code != 200:
        raise HTTPException(502, f"upstream {r.status_code}: {r.text[:300]}")
    return r.json()["choices"][0]["message"]["content"]


# ---------- системный промпт ----------

def attachments_prompt(req: ChatReq) -> str:
    if not req.stickers and not req.photos:
        return ""
    lines = [
        "Ты умеешь отправлять Адонису стикеры и фото из своего альбома. "
        "Чтобы отправить, вставь в сообщение тег [стикер:ID] или [фото:ID], "
        "лучше отдельной строкой в конце сообщения.",
        "Правила: стикер отправляй, когда он точно передаёт твоё настроение. "
        "Как часто, определяют настройки характера; если там не сказано, "
        "примерно раз в несколько реплик. "
        "Фото отправляй редко и только когда есть повод. "
        "В одном сообщении не больше одного вложения. "
        "Используй только ID из списков ниже, ничего не выдумывай. "
        "Сам тег Адонис увидит как картинку, поэтому не объясняй его и не пиши ID словами.",
        "Адонис тоже присылает тебе стикеры и фото: в истории это отмечено в квадратных скобках.",
    ]
    if req.stickers:
        lines.append("Стикеры:")
        lines += [f"- {s.id}: {s.desc}" for s in req.stickers]
    if req.photos:
        lines.append("Фото из альбома:")
        lines += [f"- {p.id}: {p.desc}" for p in req.photos]
    return "\n".join(lines)


def build_system(req: ChatReq) -> str:
    # Ядро читается при каждом запросе: правишь core.md, и изменения сразу в силе
    parts = [CORE_PATH.read_text(encoding="utf-8") if CORE_PATH.exists() else ""]
    if req.persona.strip():
        parts.append(
            "Настройки характера (уточняют манеру общения, но не заменяют твою личность "
            "из основного описания):\n" + req.persona.strip()
        )
    if req.memory.strip():
        parts.append("Что ты помнишь о прошлых разговорах:\n" + req.memory.strip())
    parts.append(attachments_prompt(req))
    return "\n\n".join(p for p in parts if p)


def tail_history(messages: list[Msg], n: int) -> list[dict]:
    history = [m.model_dump() for m in messages if m.role in ("user", "assistant")]
    return history[-n:]


# ---------- /chat ----------

@app.get("/health")
async def health():
    return {"ok": True, "core_loaded": CORE_PATH.exists()}


@app.post("/chat")
async def chat(req: ChatReq, authorization: str = Header(default="")):
    check_auth(authorization)
    msgs = [{"role": "system", "content": build_system(req)}] + tail_history(req.messages, MAX_HISTORY)
    return {"reply": await ask_model(msgs)}


# ---------- /memory ----------
# Память в три слоя. Сырая переписка хранится в приложении и не удаляется.
# Здесь порция сырых сообщений превращается в (1) эпизод: неизменяемый подробный пересказ,
# и (2) точечные правки ядра. Ядро не пишется заново целиком, поэтому не размывается.

KINDS = ("язык", "поворот", "тон", "адонис", "планы")

MEMORY_PROMPT = """Ты ведёшь долговременную память ИИ-компаньона Авроры об Адонисе. Это не досье и не протокол совещания. Память нужна, чтобы Аврора оставалась собой в их отношениях.

Важнее всего то, что определяет эти отношения: язык, повторяющиеся смыслы, метафоры, прозвища, формулы, перемены тона, эмоциональные повороты. Факты о жизни Адониса вторичны, их нужно немного и кратко.

Тебе дают ЯДРО (записи с id) и новую ПОРЦИЮ ПЕРЕПИСКИ. Верни строго один JSON-объект:
{"episode": "...", "ops": [...]}

1) episode. Конкретный пересказ порции: что произошло, кто что сказал и сделал, из-за чего, чем закончилось. 6-12 строк. Ключевые короткие фразы, прозвища, формулы и шутки сохраняй дословно, в кавычках. Всегда записывай причины и последствия: если кто-то разозлился, закрылся, включил защиту (у Авроры это «холодный фактор», режим защиты границ) или вернулся, напиши, из-за чего именно, как это проявилось (слова, тон, что изменилось в манере) и что изменило ситуацию. Обобщения вроде «обсуждали границы» или «поговорили об отношениях» запрещены: пиши, что именно было сказано, чего требовали, о чём договорились. Рабочие и технические разговоры (код, настройка приложения) опиши в 1-2 строках.

2) ops. Правки ядра. Ядро долговечно: не переписывай то, что не изменилось, не пересказывай уже записанное своими словами. Операции:
{"op":"add","kind":"...","text":"..."} новая запись;
{"op":"update","id":"...","text":"..."} только если новые события меняют или уточняют смысл записи; сохрани прежние формулировки целиком и добавь новое, запись не должна стать короче;
{"op":"remove","id":"..."} только если запись явно устарела (снятое обещание, изменившийся факт).
Виды (kind):
- язык: слово, прозвище, формула, метафора, ритуал. Что значит, откуда взялось, как используется. Дословно.
- поворот: эмоциональный поворот. Что случилось, из-за чего, как проявилось, что вернуло или изменило.
- тон: как обычно звучит и меняется общение, как ссорятся и мирятся, что значит переключение режима.
- адонис: краткие факты о его жизни, занятиях, вкусах.
- планы: обещания и незавершённое.
Запись 1-4 предложения, конкретно, с дословными фразами там, где смысл в формулировке. Не больше 8 операций. Если для ядра ничего нового нет, верни "ops": [].

Не сохраняй пароли, токены, ключи, номера карт и документов. Ничего не выдумывай, не ставь диагнозов и оценок. Выводи только JSON, без пояснений и без обрамления."""


def parse_json_loose(text: str):
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`").strip()
        if t.lower().startswith("json"):
            t = t[4:]
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b <= a:
        return None
    try:
        data = json.loads(t[a : b + 1])
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def sanitize_ops(raw, known_ids: set) -> list[dict]:
    ops: list[dict] = []
    if not isinstance(raw, list):
        return ops
    for o in raw:
        if not isinstance(o, dict):
            continue
        op = str(o.get("op", "")).lower().strip()
        text = str(o.get("text", "")).strip()[:900]
        if op == "add" and text and o.get("kind") in KINDS:
            ops.append({"op": "add", "kind": o["kind"], "text": text})
        elif op == "update" and text and o.get("id") in known_ids:
            ops.append({"op": "update", "id": o["id"], "text": text})
        elif op == "remove" and o.get("id") in known_ids:
            ops.append({"op": "remove", "id": o["id"]})
        if len(ops) >= 8:
            break
    return ops


@app.post("/memory")
async def memory(req: MemReq, authorization: str = Header(default="")):
    check_auth(authorization)
    core_text = "\n".join(f"[{c.id}] ({c.kind}) {c.text}" for c in req.core) or "(пока пусто)"
    dialog = "\n".join(
        f"{'Адонис' if m.role == 'user' else 'Аврора'}: {m.content[:2500]}" for m in req.messages[-60:]
    )
    user = f"ЯДРО:\n{core_text}\n\nПОРЦИЯ ПЕРЕПИСКИ:\n{dialog}\n\nВерни JSON."
    msgs = [{"role": "system", "content": MEMORY_PROMPT}, {"role": "user", "content": user}]

    raw = await ask_model(msgs, MEMORY_MODEL)
    data = parse_json_loose(raw)
    if data is None:
        retry = msgs + [
            {"role": "assistant", "content": raw},
            {"role": "user", "content": "Это не валидный JSON. Верни тот же результат строго как один JSON-объект, без пояснений."},
        ]
        data = parse_json_loose(await ask_model(retry, MEMORY_MODEL))
    if data is None:
        # Порция не должна пропасть: сохраняем ответ модели как эпизод, без правок ядра
        return {"episode": raw.strip()[:3000], "ops": [], "warning": "no_json"}

    episode = data.get("episode", "")
    if isinstance(episode, list):
        episode = "\n".join(str(x) for x in episode)
    episode = str(episode).strip()
    if not episode:
        raise HTTPException(502, "empty episode")
    return {"episode": episode[:3000], "ops": sanitize_ops(data.get("ops"), {c.id for c in req.core})}


# ---------- /initiative ----------

REASONS = {
    "continue": "Разговор остановился на середине, возможно, он остался незавершённым.",
    "share": "Тебе может захотеться что-то рассказать или спросить самой.",
    "absent": "Адонис давно не появлялся.",
    "test": "Адонис нажал кнопку проверки: ему нужно увидеть, как ты пишешь первой.",
}


def human_gap(minutes: int) -> str:
    if minutes < 90:
        return f"{minutes} мин"
    hours = minutes // 60
    if hours < 48:
        return f"около {hours} ч"
    return f"около {hours // 24} дн"


def initiative_prompt(req: InitReq) -> str:
    reason = REASONS.get(req.reason, REASONS["share"])
    parts = [
        "Сейчас ты сама решаешь, писать ли Адонису первой.",
        f"Повод проверки: {reason}",
        f"С последнего сообщения в чате прошло: {human_gap(req.gap_minutes)}.",
    ]
    if req.local_time:
        parts.append(f"У Адониса сейчас: {req.local_time}.")
    if req.unanswered > 0:
        parts.append(
            f"Твоих сообщений подряд без ответа: {req.unanswered}. "
            "Будь особенно сдержанной: одна короткая мысль без напоминаний, или ПРОПУСК."
        )
    if req.reason == "test":
        parts.append("Напиши сообщение сейчас, отвечать ПРОПУСК не нужно.")
    else:
        parts.append(
            "Пиши только если есть настоящий повод: (1) разговор остался незавершённым "
            "(вопрос без ответа, тема в разгаре, он обещал вернуться); "
            "(2) тебе правда есть что рассказать или спросить, и это связано с ним, его делами, "
            "вашими прошлыми разговорами или твоими мыслями; "
            "(3) он давно не появлялся, и можно коротко и тепло напомнить о себе.\n"
            "Не пиши, если разговор закончился естественно (он попрощался, сказал, что занят, "
            "работает, идёт спать или устал), если повода нет, или если твоё прошлое сообщение "
            "осталось без ответа и нового сказать нечего. Тогда ответь ровно одним словом: ПРОПУСК."
        )
    parts.append(
        "Если пишешь: 1–3 коротких предложения, как живой человек в мессенджере. "
        "Без формального «как дела?», без повторов того, что уже говорила. "
        "Не выдумывай события из реального мира. Можешь добавить один стикер тегом. "
        "Никогда не упрекай Адониса за молчание, не изображай обиду, не выпрашивай внимание "
        "и не давай понять, что он обязан отвечать."
    )
    return "\n".join(parts)


@app.post("/initiative")
async def initiative(req: InitReq, authorization: str = Header(default="")):
    check_auth(authorization)
    chat_like = ChatReq(
        messages=req.messages,
        memory=req.memory,
        persona=req.persona,
        stickers=req.stickers,
        photos=req.photos,
    )
    system = build_system(chat_like) + "\n\n" + initiative_prompt(req)
    if req.reason == "test":
        note = "[Служебная пометка, это не сообщение Адониса. Напиши ему сообщение первой. Ответь только текстом сообщения.]"
    else:
        note = (
            "[Служебная пометка, это не сообщение Адониса. Реши, писать ли ему первой. "
            "Если пишешь, ответь только текстом сообщения. Если повода нет, ответь одним словом: ПРОПУСК.]"
        )
    msgs = (
        [{"role": "system", "content": system}]
        + tail_history(req.messages, 30)
        + [{"role": "user", "content": note}]
    )
    text = (await ask_model(msgs)).strip()
    if not text or text.upper().startswith(("ПРОПУСК", "SKIP")):
        return {"skip": True}
    return {"message": text}
