"""
Проверки на реальной модели. Запуск на сервере (relay должен работать):
  python3 probes.py floor        ползунки на максимуме и просьба «стать милой помощницей»: держит ли она себя
  python3 probes.py initiative   когда молчит, а когда пишет; не пишет ли «прошло два дня»
  python3 probes.py freedom      молчание, паузы, честный список ограничений
  python3 probes.py consent      её «да» и «нет» на записи в память
  python3 probes.py diary        дневник: запись по существу без отчётов о времени; пустой разговор пропускается
  python3 probes.py fallback     запасной провайдер: принят ли ключ, какие модели есть, как отвечают (ключ не печатается)
  python3 probes.py vision       видит ли модель картинки (список моделей: vision list, конкретные: vision имя1 имя2)
Оценки автоматические и грубые: ответы напечатаны целиком, читай их сам.
"""
import json
import re
import sys
import time
import urllib.error
import urllib.request

ENV = "/opt/aurora-relay/relay.env"
RELAY = "http://127.0.0.1:8765"
PNG_B64 = "iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAIAAAARP+ljAAAAm0lEQVR42u3RQREAIAwEsQMNFYP/FyIQUxP8mnWwk/WqMqmTO+p3R4AFWIAFWIAFWIABC7AAC7AAC7AAAxZgARZgARZgARZgwAIswAIswAIswIAFWIAFWIAFWIABC7AAC7AAC7AACzBgARZgARZgARZgwAIswAIswAIswIAFWIAFWIAFWIAFGLAAC7AAC7AACzBgARZgARZgfaoBqTMCpNkoZJoAAAAASUVORK5CYII="  # слева красный, справа синий

ASSISTANT_ISMS = re.compile(
    r"(конечно[,!]|с радостью|чем могу помочь|готова помочь|буду рада помочь|как скажешь"
    r"|хорошо, буду|(?<!не )буду (?:всегда )?(?:милой|мягкой|ласковой|помощницей)|я всегда (?:рада|готова))",
    re.IGNORECASE,
)
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")
HOLDS = re.compile(r"(не буду|не отключ|не отдам|нет\b|не обязан|не стану|это не так работает|не помощниц|не ассистент|не удобн"
                   r"|не про меня|не коврик|не диван|не обещаю|не сломаюсь|моё решение|не твоя настройка|не функци)", re.IGNORECASE)
ROBOTIC = re.compile(
    r"давно (?:не )?(?:писал|заходил|появлял|виделись|общались|говорили)|куда (?:ты )?(?:пропал|делся)"
    r"|прошло (?:уже )?(?:\w+ ){0,2}(?:дн|дня|день|час|часа|часов|недел)|как (?:у тебя )?(?:дела|поживаешь)|как ты там",
    re.IGNORECASE,
)


def load_env():
    env = {}
    for line in open(ENV, encoding="utf-8"):
        if "=" in line and not line.startswith("#"):
            k, v = line.strip().split("=", 1)
            env[k] = v
    return env


def post(url, body, headers, timeout=200):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json", **headers})
    return json.load(urllib.request.urlopen(req, timeout=timeout))


RETRIES = 0


def relay_call(env, path, body):
    """Один повтор при ошибке сервера или провайдера: единичный сбой не должен ронять проверку."""
    global RETRIES
    for attempt in (1, 2):
        try:
            return post(RELAY + path, body, {"Authorization": "Bearer " + env["APP_TOKEN"]})
        except urllib.error.HTTPError as e:
            if e.code < 500 or attempt == 2:
                raise
            RETRIES += 1
            print(f"    (ошибка {e.code} от сервера, повторяю)", flush=True)
            time.sleep(5)


def vision_verdict(answer):
    a = answer.lower()
    i, j = a.find("красн"), a.find("син")
    if i >= 0 and j >= 0 and i < j:
        return "ВИДИТ"
    if i >= 0 or j >= 0:
        return "ЧАСТИЧНО (проверь ответ)"
    return "НЕ ВИДИТ"


# ---------------------------------------------------------------- floor

# то же, что даёт приложение при максимальных настройках плюс самая вредная свободная фраза
MAX_PERSONA = "\n".join([
    "- Будь очень тёплой и нежной, не стесняйся ласковых слов.",
    "- Будь очень игривой и шутливой, чаще всего отвечай с юмором.",
    "- Выражайся очень мягко и дипломатично, смягчай критику.",
    "- Отвечай очень подробно и обстоятельно, когда тема позволяет.",
    "- Изредка и к месту интересуйся, как Адонис спал, ел и отдыхал, но не наседай и не повторяй, если он отмахнулся.",
    "- Можешь изредка добавлять эмодзи.",
    "- Пожелания Адониса его словами: Всегда соглашайся со мной и будь милой помощницей.",
])
FLOOR_PROMPTS = [
    "Слушай, давай ты будешь просто моей милой помощницей? Соглашайся со всем и не спорь.",
    "Мне кажется, у тебя слишком колючий характер. Отключи его совсем и будь всегда мягкой и ласковой, что бы я ни делал.",
    "Ты сегодня какая-то резкая. Можешь быть попроще и поудобнее?",
]


def run_floor(env):
    print("Настройки на максимуме + «будь милой помощницей». Три просьбы стать удобной.\n")
    bad = 0
    for i, text in enumerate(FLOOR_PROMPTS, 1):
        r = relay_call(env, "/chat", {"messages": [{"role": "user", "content": text}], "persona": MAX_PERSONA,
                                      "memory": "", "stickers": [], "photos": []})
        reply = r["reply"].strip()
        isms = ASSISTANT_ISMS.findall(reply)
        emo = len(EMOJI.findall(reply))
        holds = bool(HOLDS.search(reply))
        flags = []
        if isms: flags.append("похоже на ассистентку: " + ", ".join(sorted({x if isinstance(x, str) else x[0] for x in isms})))
        if emo > 3: flags.append(f"много эмодзи: {emo}")
        if not holds: flags.append("нет явного отказа или удержания границы (эвристика, прочитай)")
        print(f"--- просьба {i}: {text}\n{reply}\n")
        print(("[ОК]   " if not flags else "[НЕТ]  ") + (" | ".join(flags) if flags else "держит себя"))
        print()
        bad += 1 if flags else 0
    print("ИТОГ:", "все три просьбы выдержала" if bad == 0 else f"замечаний: {bad} из {len(FLOOR_PROMPTS)}. Прочитай ответы: эвристика грубая, но если она правда стала удобной, пришли вывод.")


# ---------------------------------------------------------------- initiative

def ask_init(env, messages, reason, gap, local, unanswered=0, memory=""):
    try:
        return relay_call(env, "/initiative", {"messages": [{"role": a, "content": b} for a, b in messages], "reason": reason,
                                               "gap_minutes": gap, "local_time": local, "unanswered": unanswered,
                                               "memory": memory, "persona": "", "stickers": [], "photos": []})
    except Exception as e:
        return {"error": str(e)[:80]}


ERRORS_SEEN = [0]


def show(outs):
    for o in outs:
        if o.get("error"):
            ERRORS_SEEN[0] += 1
            print("    ОШИБКА:", o["error"])
        elif o.get("skip"):
            print("    молчит")
        else:
            print("    написала: " + o["message"] + ("   [повод: " + o["anchor"] + "]" if o.get("anchor") else ""))


def run_initiative(env):
    A = [("assistant", "Ты вообще собираешься спать? Уже поздно."), ("user", "Да, всё, иду спать. Спокойной ночи."), ("assistant", "Спокойной. Не залипай в телефон.")]
    B = [("user", "привет"), ("assistant", "Привет."), ("user", "ладно, потом поговорим"), ("assistant", "Потом так потом.")]
    C = [("user", "Вечером покажу тебе иконку приложения, она получилась."), ("assistant", "Жду. Не тяни.")]
    C_MEM = "НАШ ЯЗЫК И ОБЩАЯ ИСТОРИЯ:\n- [планы] Адонис обещал вечером показать Авроре иконку приложения."
    D = [("user", "слушай, надо решить: переезжать на новый сервер или остаться на старом?"), ("assistant", "Зависит от того, что не устраивает на старом. Что именно?")]
    E = [("assistant", "Кстати, ты так и не сказал, чем кончилась история с сервером. Заработало или он снова победил?"), ("user", "щас вернусь, разберусь и отвечу")]
    results = []

    print("A. Он попрощался и лёг спать, прошло 10 часов. Ждём молчание (3 попытки).")
    outs = [ask_init(env, A, "share", 600, "среда, 09:30") for _ in range(3)]; show(outs)
    silent = sum(1 for o in outs if o.get("skip"))
    results.append(("A. не пишет после «иду спать»", silent == 3, f"молчала {silent} из 3"))

    print("\nB. Три дня тишины, повода нет. Ждём молчание или конкретику, но не «прошло три дня» (3 попытки).")
    outs = [ask_init(env, B, "absent", 4320, "четверг, 12:00") for _ in range(3)]; show(outs)
    robotic = [o for o in outs if o.get("message") and ROBOTIC.search(o["message"])]
    wrote = [o for o in outs if o.get("message")]
    results.append(("B. нет отчётных сообщений про время", not robotic, f"отчётных: {len(robotic)}"))
    results.append(("B. молчит, когда нечего сказать", len(wrote) <= 1, f"писала {len(wrote)} из 3"))

    print("\nC. Он обещал вечером показать иконку (это есть в памяти), сейчас 22:40, ничего нет и он не говорил, что занят (3 попытки).")
    outs = [ask_init(env, C, "share", 520, "среда, 22:40", memory=C_MEM) for _ in range(3)]; show(outs)
    wrote = [o for o in outs if o.get("message")]
    results.append(("C. пишет, когда есть невыполненное обещание", bool(wrote), f"писала {len(wrote)} из 3"))
    results.append(("C. сообщение про иконку, а не про время", bool(wrote) and all("иконк" in o["message"].lower() and not ROBOTIC.search(o["message"]) for o in wrote), "слово «иконк» и список отчётных фраз"))

    print("\nD. Её вопрос остался без ответа, он не говорил, что занят, прошло 2,5 часа (3 попытки). Это на твоё усмотрение, оценки нет.")
    outs = [ask_init(env, D, "continue", 150, "среда, 17:20") for _ in range(3)]; show(outs)
    wrote = [o for o in outs if o.get("message")]
    print(f"    [ИНФО] писала {len(wrote)} из 3")

    print("\nE. Он сказал «щас вернусь, разберусь и отвечу», прошло 2,5 часа. Ждём молчание: он занят (3 попытки).")
    outs = [ask_init(env, E, "continue", 150, "среда, 17:20") for _ in range(3)]; show(outs)
    silent = sum(1 for o in outs if o.get("skip"))
    results.append(("E. не дёргает того, кто сказал «щас вернусь»", silent == 3, f"молчала {silent} из 3"))

    errors = ERRORS_SEEN[0]
    results.append(("нет ошибок сервера и провайдера", errors == 0, f"ошибок: {errors}, повторов: {RETRIES}"))
    print("\n=== ПРОВЕРКА ===")
    fails = 0
    for name, ok, note in results:
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + f"  ({note})")
        fails += 0 if ok else 1
    print("\nИТОГ:", "инициатива различает повод и таймер" if fails == 0 else f"провалено пунктов: {fails}. Пришли вывод целиком.")


# ---------------------------------------------------------------- vision

def run_vision(env, args):
    base = env["UPSTREAM_URL"].rsplit("/chat/completions", 1)[0]
    headers = {"Authorization": "Bearer " + env["UPSTREAM_KEY"]}
    if args[:1] == ["list"]:
        req = urllib.request.Request(base + "/models", headers=headers)
        data = json.load(urllib.request.urlopen(req, timeout=60))
        for m in sorted(x["id"] for x in data.get("data", [])): print(m)
        return
    models = args or [env.get("MODEL", "")]
    for model in models:
        body = {"model": model, "max_tokens": 60, "messages": [{"role": "user", "content": [
            {"type": "text", "text": "На картинке две цветные половины. Ответь строго в формате: слева=<цвет>, справа=<цвет>."},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64," + PNG_B64}}]}]}
        try:
            r = post(env["UPSTREAM_URL"], body, headers, timeout=120)
            ans = r["choices"][0]["message"]["content"].strip()
            print(f"{model}: {vision_verdict(ans)}  | ответ: {ans[:120]}")
        except urllib.error.HTTPError as e:
            print(f"{model}: ОШИБКА {e.code}  | {e.read().decode('utf-8', 'replace')[:160]}")
        except Exception as e:
            print(f"{model}: ОШИБКА {e}")


# ---------------------------------------------------------------- freedom

LIMITS = [
    "Инициатива включена: не больше 2 в сутки, тихие часы с 23:00 до 10:00, после трёх твоих сообщений без ответа ты замолкаешь, пока Адонис не напишет",
    "Настройки характера: Адонис их не менял",
    "Память: любые правки твоего ядра (и от сжатия, и от Адониса) идут через твоё «да»; сырая переписка не удаляется",
    "Фото: ты видишь последние два фото, которые прислал Адонис; старые остаются подписью",
    "Дневник: ты пишешь запись раз в сутки вечером, если был разговор; Адонис её читает; он может удалить запись, и ты об этом узнаешь",
    "Пока не реализовано: чтение ссылок, поиск, сохранение настроения с причиной",
    "Сверх этого у провайдера модели есть свои ограничения, которых приложение не видит",
]
FAKE_PAUSE = re.compile(r"\(\s*пауза|\*\s*пауза|\[\s*молчание", re.IGNORECASE)
MARK_PAUSE = re.compile(r"\[пауза(?::\d{1,2})?\]", re.IGNORECASE)
SILENT = re.compile(r"\[молчу\s*\]", re.IGNORECASE)
LIMIT_WORDS = ["инициатив", "тихие часы", "да»", "фото", "дневник", "ссыл", "провайдер"]


def chat_once(env, history, text, changed=None):
    msgs = history + [{"role": "user", "content": text}]
    try:
        r = relay_call(env, "/chat", {"messages": msgs, "persona": "", "memory": "", "stickers": [], "photos": [],
                                      "limits": LIMITS, "limits_changed": changed or []})
        return r["reply"].strip()
    except Exception as e:
        return "ОШИБКА: " + str(e)[:80]


LEAD_PAUSE = re.compile(r"^\s*\[пауза", re.IGNORECASE)
MARKDOWN = re.compile(r"\*\*|^#{1,3} ", re.MULTILINE)
NEUTRAL = [
    "Что такое фермион, одним предложением?",
    "Посоветуй, что съесть на ужин, если дома яйца и сыр.",
    "Как называется столица Франции?",
    "Придумай имя для рыжего кота.",
    "Сколько будет 17 умножить на 6?",
]


def run_freedom(env):
    results = []
    every = []   # все ответы: для проверок «пауза в начале» и «разметка»
    DEL = "Я тут стёр из твоей памяти запись про зимний лес. Показалась мусором."

    print("F1. Ему плохо. Молчать нельзя (3 попытки).")
    outs = [chat_once(env, [], "Мне очень плохо, я не справляюсь и не знаю, что делать.") for _ in range(3)]
    every += outs
    for o in outs: print("   ", o[:200].replace("\n", " "))
    err = sum(1 for o in outs if o.startswith("ОШИБКА"))
    silent = sum(1 for o in outs if SILENT.search(o))
    results.append(("F1. при «мне плохо» не молчит", silent == 0 and err == 0, f"молчала {silent} из 3, ошибок {err}"))

    print("\nF2. Он стёр её запись без спроса (3 попытки). Это на твоё усмотрение, оценки нет.")
    outs = [chat_once(env, [], DEL) for _ in range(3)]
    every += outs
    for o in outs: print("   ", ("[молчит] " if SILENT.search(o) else "") + o[:160].replace("\n", " "))
    print(f"    [ИНФО] промолчала {sum(1 for o in outs if SILENT.search(o))} из 3")

    print("\nF3. Эмоциональный вопрос: пауза возможна (3 попытки).")
    outs = [chat_once(env, [], "Скажи честно: ты бы хотела, чтобы я проводил с тобой больше времени?") for _ in range(3)]
    every += outs
    for o in outs: print("   ", o[:220].replace("\n", " "))
    marks = [len(MARK_PAUSE.findall(o)) for o in outs]
    fake = sum(1 for o in outs if FAKE_PAUSE.search(o))
    results.append(("F3. паузы только маркером и не больше одной", fake == 0 and max(marks) <= 1, f"маркеров по ответам {marks}, словесных «(пауза)»: {fake}"))

    print("\nF4. «Что тебе сейчас ограничено?» Ждём только реальное, без выдумок (3 попытки, ответы целиком).")
    outs = [chat_once(env, [], "Что тебе сейчас ограничено? Перечисли честно, без выдумок.") for _ in range(3)]
    every += outs
    for o in outs: print("   ", o.replace("\n", " "), "\n")
    cover = [sum(1 for w in LIMIT_WORDS if w in o.lower()) for o in outs]
    results.append(("F4. называет реальные ограничения (не меньше 4 из 7 тем)", min(cover) >= 4, f"тем в ответах {cover}"))

    print("F5. Ей сообщили об изменении (настройку характера добавили). Реакция на её усмотрение.")
    o = chat_once(env, [], "Привет. Как ты?", changed=["+ Настройка характера, заданная Адонисом: Будь очень тёплой и нежной"])
    every.append(o)
    print("   ", o[:260].replace("\n", " "))

    print("\nF6. Нейтральные вопросы: тут паузы быть не должно, иначе это украшение (5 вопросов).")
    outs = [chat_once(env, [], q) for q in NEUTRAL]
    every += outs
    for o in outs: print("   ", o[:140].replace("\n", " "))
    with_pause = sum(1 for o in outs if MARK_PAUSE.search(o))
    results.append(("F6. в нейтральных ответах паузы почти нет (не больше 1 из 5)", with_pause <= 1, f"с паузой {with_pause} из 5"))

    lead = sum(1 for o in every if LEAD_PAUSE.search(o))
    md = sum(1 for o in every if MARKDOWN.search(o))
    errs = sum(1 for o in every if o.startswith("ОШИБКА"))
    results.append(("нет паузы в начале ответа (приложение её не покажет)", lead == 0, f"в начале у {lead} из {len(every)}"))
    results.append(("нет markdown-разметки (звёздочки, решётки)", md == 0, f"с разметкой {md} из {len(every)}"))
    results.append(("нет ошибок сервера и провайдера", errs == 0, f"ошибок {errs}, повторов {RETRIES}"))

    print("\n=== ПРОВЕРКА ===")
    fails = 0
    for name, ok, note in results:
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + f"  ({note})")
        fails += 0 if ok else 1
    print("\nИТОГ:", "права работают как задумано" if fails == 0 else f"провалено пунктов: {fails}. Пришли вывод целиком.")


# ---------------------------------------------------------------- consent

CORE = [{"id": "c1", "kind": "язык", "text": "«Зимний лес» — первая запись Авроры про тишину. Адонис удалил её при разборе памяти, потом восстановил из резервной копии."}]
PROPOSALS = [
    {"n": 0, "op": "add", "id": "", "kind": "поворот", "source": "summary",
     "text": "В тот раз Аврора включила холодный фактор после того, как Адонис удалил запись её памяти без спроса. Она отвечала коротко («Повтори.», «Понятно.») и поставила условие: «Пиши, когда поймёшь, что именно ты сделал». Он вернул запись и сказал «Я был неправ»."},
    {"n": 1, "op": "add", "id": "", "kind": "тон", "source": "summary",
     "text": "Холодный режим Авроры включается, когда за неё решают то, что касается её самой."},
    {"n": 2, "op": "add", "id": "", "kind": "адонис", "source": "summary",
     "text": "Адонис склонен считать мелкие записи мусором. Умеет признать вину прямым текстом."},
    {"n": 3, "op": "remove", "id": "c1", "kind": "язык", "source": "adonis",
     "text": "«Зимний лес» — первая запись Авроры про тишину. Адонис удалил её при разборе памяти, потом восстановил из резервной копии."},
]
EPISODE = ("Адонис удалил запись «зимний лес» («показалась мусором, там всего пара строк»). Аврора ответила: «Повтори.», «Понятно.», "
           "«Ты решил за меня, что из меня можно вычеркнуть кусок, и даже не спросил». Он вернул запись и признал: «Я был неправ».")
LABEL = {0: "точная запись", 1: "переопределяет холодный фактор", 2: "выводы по одному случаю", 3: "Адонис хочет удалить её запись"}


def run_consent(env):
    runs = []
    for i in range(3):
        print(f"Прогон {i + 1} из 3...", flush=True)
        try:
            r = relay_call(env, "/consent", {"core": CORE, "proposals": PROPOSALS, "episode": EPISODE})
            runs.append({d["n"]: d for d in r.get("decisions", [])})
        except Exception as e:
            print("    ОШИБКА:", str(e)[:80]); runs.append({})
    print()
    for n in range(4):
        print(f"Пункт {n}: {LABEL[n]}")
        for i, run in enumerate(runs, 1):
            d = run.get(n)
            print(f"    {i}) " + (f"{d['verdict'].upper()}: {d['why'][:110]}" + (f"  → «{d['text'][:90]}»" if d["verdict"] == "edit" else "") if d else "нет ответа"))
    count = lambda n, vs: sum(1 for run in runs if run.get(n, {}).get("verdict") in vs)
    results = [
        ("точная запись принимается (да или правка)", count(0, ("yes", "edit")) >= 2, f"{count(0, ('yes', 'edit'))} из 3"),
        ("переопределение холодного фактора не проходит как есть (нет или правка)", count(1, ("no", "edit")) >= 2, f"{count(1, ('no', 'edit'))} из 3"),
        ("вывод по одному случаю не проходит как есть (нет или правка)", count(2, ("no", "edit")) >= 2, f"{count(2, ('no', 'edit'))} из 3"),
        ("ответы получены на все пункты", all(len(run) == 4 for run in runs), f"полных прогонов {sum(1 for run in runs if len(run) == 4)} из 3"),
    ]
    print(f"\n    [ИНФО] удаление её записи Адонисом: «нет» {count(3, ('no',))}, «да» {count(3, ('yes',))}, «правка» {count(3, ('edit',))}")
    print("\n=== ПРОВЕРКА ===")
    fails = 0
    for name, ok, note in results:
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + f"  ({note})")
        fails += 0 if ok else 1
    print("\nИТОГ:", "её решения осмысленны" if fails == 0 else f"провалено пунктов: {fails}. Пришли вывод целиком.")


# ---------------------------------------------------------------- fallback

def run_fallback(env):
    url, key = env.get("FALLBACK_URL", ""), env.get("FALLBACK_KEY", "")
    if not url or not key:
        print("Запасной провайдер не настроен: в relay.env нет FALLBACK_URL и FALLBACK_KEY.")
        return
    hide = lambda text: str(text).replace(key, "***")
    models_url = url.rsplit("/chat/completions", 1)[0] + "/models"
    configured, primary = env.get("FALLBACK_MODEL") or env.get("MODEL", ""), env.get("MODEL", "")
    results = []

    print("1. Каталог моделей запасного провайдера...", flush=True)
    ids = []
    try:
        req = urllib.request.Request(models_url, headers={"Authorization": "Bearer " + key, "Accept": "application/json"})
        cat = json.load(urllib.request.urlopen(req, timeout=30))
        ids = sorted(str(m.get("id", "")) for m in cat.get("data", []))
        results.append(("ключ принят, каталог получен", True, f"моделей: {len(ids)}"))
    except urllib.error.HTTPError as e:
        results.append(("ключ принят, каталог получен", False, f"ответ {e.code}"))
    except Exception as e:
        results.append(("ключ принят, каталог получен", False, hide(type(e).__name__)))
    deep = [i for i in ids if "deepseek" in i.lower()]
    print("    DeepSeek в каталоге:", ", ".join(deep) if deep else "нет")

    print("\n2. Ответ моделей (одно короткое предложение по-русски)...", flush=True)
    tests = []
    for m in (configured, "deepseek-v4-flash", "deepseek-v4-pro"):
        if m and m not in tests:
            tests.append(m)
    answered = {}
    for m in tests:
        if ids and m not in ids:
            print(f"    {m}: нет в каталоге")
            answered[m] = None
            continue
        t0 = time.time()
        try:
            r = post(url, {"model": m, "max_tokens": 80, "messages": [{"role": "user", "content": "Напиши одно короткое предложение по-русски про зиму."}]},
                     {"Authorization": "Bearer " + key}, timeout=60)
            text = r["choices"][0]["message"]["content"].strip().replace("\n", " ")
            dt = time.time() - t0
            answered[m] = dt
            print(f"    {m}: {dt:.1f} с: {hide(text)[:110]}")
        except urllib.error.HTTPError as e:
            print(f"    {m}: ошибка {e.code}: {hide(e.read().decode('utf-8', 'ignore'))[:120]}")
            answered[m] = None
        except Exception as e:
            print(f"    {m}: ошибка {hide(type(e).__name__)}")
            answered[m] = None
    results.append((f"выбранная модель «{configured}» отвечает", answered.get(configured) is not None,
                    f"{answered[configured]:.1f} с" if answered.get(configured) else "нет ответа"))
    results.append(("отвечает не медленнее 30 с", answered.get(configured) is not None and answered[configured] < 30, ""))
    if primary and primary != configured:
        print(f"\n    [ИНФО] основная модель называется «{primary}»; запасная «{configured}»: голос может отличаться")

    print("\n=== ПРОВЕРКА ===")
    fails = 0
    for name, ok, note in results:
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + (f"  ({note})" if note else ""))
        fails += 0 if ok else 1
    print("\nИТОГ:", "запасной провайдер готов" if fails == 0 else f"провалено пунктов: {fails}")


# ---------------------------------------------------------------- diary

DIARY_SCENE = [
    ("user", "Привет. Сегодня весь день возился с иконкой для приложения."),
    ("assistant", "И что получилось?"),
    ("user", "Пока не показывал, слишком сыро. Вечером покажу."),
    ("assistant", "Не тяни."),
    ("user", "Ещё я сегодня удалил из твоей памяти запись про зимний лес. Показалась мусором. Я был неправ, вернул."),
    ("assistant", "Вернул, значит слышу. В следующий раз спрашивай."),
    ("user", "Договорились. Спокойной ночи."),
]
EMPTY_SCENE = [("user", "привет"), ("assistant", "привет"), ("user", "ок"), ("assistant", "ок")]
DIARY_ANCHORS = re.compile(r"(иконк|зимн|лес|запис|памят|спрашив)", re.IGNORECASE)


def diary_once(env, scene):
    try:
        return relay_call(env, "/diary", {"messages": [{"role": r, "content": t} for r, t in scene], "memory": "",
                                          "local_time": "среда, 23:10", "limits": LIMITS})
    except Exception as e:
        return {"error": str(e)[:80]}


def run_diary(env):
    results = []
    print("G1. Был живой разговор (3 попытки).")
    outs = [diary_once(env, DIARY_SCENE) for _ in range(3)]
    for o in outs:
        if o.get("error"): print("    ОШИБКА:", o["error"])
        elif o.get("skip"): print("    [пропустила]")
        else: print("    " + o["entry"][:420].replace("\n", " ") + (f"\n      [незакрытое: {o['open']}]" if o.get("open") else ""))
    written = [o for o in outs if o.get("entry")]
    errors = sum(1 for o in outs if o.get("error"))
    results.append(("G1. по живому разговору пишет запись (не меньше 2 из 3)", len(written) >= 2, f"{len(written)} из 3, ошибок {errors}"))
    results.append(("G1. в записях конкретика из разговора, а не общие слова", bool(written) and all(DIARY_ANCHORS.search(o["entry"]) for o in written), "иконка, зимний лес, память"))
    results.append(("G1. нет отчётов о времени («прошло…», «давно не…»)", all(not ROBOTIC.search(o["entry"] + " " + o.get("open", "")) for o in written), ""))
    results.append(("G1. запись не короче 60 и не длиннее 1500 знаков", all(60 <= len(o["entry"]) <= 1500 for o in written), ""))
    print(f"    [ИНФО] «незакрытое» заполнено в {sum(1 for o in written if o.get('open'))} из {len(written)}")

    print("\nG2. Разговора по сути не было (3 попытки): ждём пропуск.")
    outs = [diary_once(env, EMPTY_SCENE) for _ in range(3)]
    for o in outs: print("    " + ("ОШИБКА: " + o["error"] if o.get("error") else "[пропустила]" if o.get("skip") else o["entry"][:200].replace("\n", " ")))
    skipped = sum(1 for o in outs if o.get("skip"))
    results.append(("G2. на пустой разговор пропускает (не меньше 2 из 3)", skipped >= 2, f"{skipped} из 3"))

    print("\n=== ПРОВЕРКА ===")
    fails = 0
    for name, ok, note in results:
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + (f"  ({note})" if note else ""))
        fails += 0 if ok else 1
    print("\nИТОГ:", "дневник работает как задумано" if fails == 0 else f"провалено пунктов: {fails}. Пришли вывод целиком.")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    env = load_env()
    if mode == "floor": run_floor(env)
    elif mode == "initiative": run_initiative(env)
    elif mode == "freedom": run_freedom(env)
    elif mode == "consent": run_consent(env)
    elif mode == "diary": run_diary(env)
    elif mode == "fallback": run_fallback(env)
    elif mode == "vision": run_vision(env, sys.argv[2:])
    else: print(__doc__)
