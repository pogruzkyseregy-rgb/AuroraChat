# Аврора: версия 0.8 (дневник Авроры; всё из 0.7: молчание, паузы, её «да» на память, список ограничений)

## 1. Сервер (Termux)
    Z=$(ls -t /storage/emulated/0/Download/aurora-chat-v8*.zip | head -1); echo "$Z"
    unzip -p "$Z" aurora-relay/relay.py > ~/relay.new; wc -c ~/relay.new
    [ -s ~/relay.new ] && scp ~/relay.new root@92.118.112.46:/opt/aurora-relay/relay.py && ssh root@92.118.112.46 "systemctl restart aurora-relay"

## 2. Приложение
1. Загрузить aurora-chat-v8.zip в корень репозитория (Add file → Upload files).
2. Actions → Unpack → Run workflow. Дождаться зелёной галочки.
3. Проверка: в репозитории файл app/build.gradle.kts, в нём versionName = "0.8"; zip из корня исчез.
4. Actions → Build APK → Run workflow (вручную, уже ПОСЛЕ шага 3). Скачать артефакт aurora-chat.
5. Установить поверх. Проверка: Настройки → внизу строка «Версия 0.8».
