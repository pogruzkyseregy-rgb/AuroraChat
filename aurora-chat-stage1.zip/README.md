# Аврора: приложение-чат, этап 1

## A. Сервер (на VPS, по SSH)

    mkdir -p /opt/aurora-relay && cd /opt/aurora-relay
    # положить сюда relay.py, aurora-relay.service, relay.env.example и свой AvrorA_Core.md
    mv AvrorA_Core.md core.md
    python3 -m venv venv
    venv/bin/pip install fastapi uvicorn httpx
    cp relay.env.example relay.env
    openssl rand -hex 24          # это будет APP_TOKEN
    nano relay.env                # вписать URL, ключ, модель и токен (как у сайта)
    chmod 600 relay.env
    cp aurora-relay.service /etc/systemd/system/
    systemctl daemon-reload && systemctl enable --now aurora-relay
    curl http://127.0.0.1:8765/health    # должно быть {"ok":true,"core_loaded":true}

Дальше вставить nginx-snippet.conf в конфиг сайта, затем:

    nginx -t && systemctl reload nginx

## B. Приложение (GitHub)

1. Новый репозиторий, например AuroraChat. Залить содержимое папки AuroraChat
   (удобнее всего с VPS: распаковать архив, git init, git push).
2. Actions соберёт APK сам. Он будет во вкладке Actions → последний запуск → Artifacts.
3. При первом запуске откроются настройки: адрес уже вписан, остаётся вставить APP_TOKEN.

## C. Постоянная подпись (сделать один раз, до того как начнёшь переписываться)

Без неё каждая новая сборка подписана другим ключом, обновление не встанет,
а удаление приложения сотрёт переписку.

    apt install -y openjdk-17-jre-headless
    keytool -genkeypair -v -keystore aurora.jks -alias aurora -keyalg RSA -keysize 2048 -validity 10000
    base64 -w0 aurora.jks        # вывод скопировать

В GitHub: Settings → Secrets and variables → Actions → New repository secret:
- KEYSTORE_B64: вывод base64
- KS_PASS: пароль, который ты задал в keytool
- KS_ALIAS: aurora

aurora.jks сохрани в надёжном месте: без него обновлять приложение не получится.
