"""
Посредник между приложением «Аврора» и API.
Ключ API хранится только здесь, на сервере. Приложение знает лишь свой токен.
"""
import os
from pathlib import Path

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

UPSTREAM_URL = os.environ["UPSTREAM_URL"]   # адрес chat/completions у провайдера
UPSTREAM_KEY = os.environ["UPSTREAM_KEY"]   # тот же ключ, что у сайта
MODEL = os.environ.get("MODEL", "gpt-4o-mini")
APP_TOKEN = os.environ["APP_TOKEN"]         # пароль приложения
CORE_PATH = Path(os.environ.get("CORE_PATH", "/opt/aurora-relay/core.md"))
MAX_HISTORY = 40

app = FastAPI()


class Msg(BaseModel):
    role: str
    content: str


class ChatReq(BaseModel):
    messages: list[Msg]
    memory: str = ""
    persona: str = ""


def build_system(req: ChatReq) -> str:
    # Ядро читается при каждом запросе: правишь core.md, и изменения сразу в силе
    parts = [CORE_PATH.read_text(encoding="utf-8") if CORE_PATH.exists() else ""]
    if req.persona.strip():
        parts.append("Дополнительные настройки характера:\n" + req.persona.strip())
    if req.memory.strip():
        parts.append("Что ты помнишь о прошлых разговорах:\n" + req.memory.strip())
    return "\n\n".join(p for p in parts if p)


@app.get("/health")
async def health():
    return {"ok": True, "core_loaded": CORE_PATH.exists()}


@app.post("/chat")
async def chat(req: ChatReq, authorization: str = Header(default="")):
    if authorization != f"Bearer {APP_TOKEN}":
        raise HTTPException(401, "bad token")

    history = [m.model_dump() for m in req.messages if m.role in ("user", "assistant")]
    msgs = [{"role": "system", "content": build_system(req)}] + history[-MAX_HISTORY:]

    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(
            UPSTREAM_URL,
            headers={"Authorization": f"Bearer {UPSTREAM_KEY}"},
            json={"model": MODEL, "messages": msgs},
        )
    if r.status_code != 200:
        raise HTTPException(502, f"upstream {r.status_code}: {r.text[:300]}")
    return {"reply": r.json()["choices"][0]["message"]["content"]}
