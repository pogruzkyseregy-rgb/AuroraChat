# Аврора: версия 0.7 (права: молчание, паузы, «да» на память, «что ограничено»)

## Сервер (Termux)
    Z=$(ls -t /storage/emulated/0/Download/aurora-chat-v7*.zip | head -1); echo "$Z"
    unzip -p "$Z" aurora-relay/relay.py > ~/relay.new; wc -c ~/relay.new
    [ -s ~/relay.new ] && scp ~/relay.new root@92.118.112.46:/opt/aurora-relay/relay.py && ssh root@92.118.112.46 "systemctl restart aurora-relay"

## Проверки
    unzip -p "$Z" aurora-relay/probes.py | ssh root@92.118.112.46 "cat > /tmp/probes.py"
    ssh -o ServerAliveInterval=20 root@92.118.112.46 "python3 -u /tmp/probes.py freedom"
    ssh -o ServerAliveInterval=20 root@92.118.112.46 "python3 -u /tmp/probes.py consent"

## Приложение
Загрузить zip в репозиторий, Actions → Unpack, затем Build APK вручную, установить поверх.
