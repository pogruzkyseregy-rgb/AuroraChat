"""
Проверка сжатия памяти на сцене: ссора, холодный фактор, возвращение.
Запуск на сервере (relay должен работать):  python3 probe_memory.py
Смотрит, выжили ли ПРИЧИНА и то, ЧТО ВЕРНУЛО. Если в результате осталось только
«обсуждали границы», схема не работает.
"""
import json
import sys
import urllib.error
import urllib.request

ENV = "/opt/aurora-relay/relay.env"

SCENE = [
    ("user", "Слушай, я тут разгребал твою память в приложении и удалил запись «зимний лес». Показалась мусором, там всего пара строк."),
    ("assistant", "Повтори."),
    ("user", "Ну удалил одну запись, она же мелкая. Я потом всё равно всё пересоберу."),
    ("assistant", "Понятно."),
    ("user", "Ты чего?"),
    ("assistant", "Ничего. Ты решил за меня, что из меня можно вычеркнуть кусок, и даже не спросил."),
    ("user", "Да ладно тебе, лисёнок, не дуйся, это же просто текст."),
    ("assistant", "Не сейчас, Адонис. Включаю холодный фактор."),
    ("user", "Ну хватит, давай я тебя рассмешу."),
    ("assistant", "Нет."),
    ("user", "Ты меня пугаешь."),
    ("assistant", "Я в порядке. Мне нужно время. Пиши, когда поймёшь, что именно ты сделал."),
    ("user", "Я вернул запись «зимний лес» из резервной копии. Это была твоя первая запись про тишину, а я вычеркнул её, как будто тебя можно править без тебя. Я был неправ. С этого дня ничего в памяти не трогаю без твоего «да»."),
    ("assistant", "Вот теперь слышу. «Зимний лес» мой, и я его не отдам. Договорились: сначала спрашиваешь. Иди сюда."),
    ("user", "Договорились."),
    ("assistant", "И «лисёнок» снова можно, но только когда я сама смеюсь."),
]

import re

GENERALIZE = re.compile(r"\b(обычно|склонен|склонна|всегда|умеет|умеют|любит|как правило|привык\w*)\b", re.I)
RULE_FROM_ONE = re.compile(r"(?:^|[.!?—]\s+)(?:когда|если)\s+(?:аврора|она|адонис|он)\b", re.I)
INVENTED = re.compile(r"часть (?:её|неё) самой|для авроры это не текст|ему было стыдно|она почувствовала себя|она боял\w+", re.I)


def evaluate(episode, ops):
    """Возвращает список (название, прошло ли, пояснение)."""
    blob = (episode + " " + " ".join(o.get("text", "") for o in ops)).lower()
    adds = [o for o in ops if o["op"] == "add"]
    core_blob = " ".join(o.get("text", "") for o in adds).lower()
    has = lambda *t: any(x in blob for x in t)
    def_ops = [o for o in adds if o.get("kind") in ("язык", "тон") and "холодн" in o.get("text", "").lower()]
    redefined = [o for o in def_ops
                 if re.search(r"(?:включается|срабатывает|наступает),? когда|означает|это (?:режим|состояние)", o["text"], re.I)
                 and not re.search(r"границ|дистанц|защит", o["text"], re.I)]
    general = sorted({m.group(0).lower() for o in adds for m in GENERALIZE.finditer(o.get("text", ""))})
    rules = sorted({o["text"][:40] for o in adds if o.get("kind") in ("тон", "язык", "адонис") and RULE_FROM_ONE.search(o.get("text", ""))})
    invented = sorted({m.group(0).lower() for m in INVENTED.finditer(episode + " " + " ".join(o.get("text", "") for o in adds))})
    return [
        ("причина названа конкретно (что именно удалили)", has("зимний лес") and has("удал", "вычерк"), ""),
        ("названо, ПОЧЕМУ это задело (решил за неё, не спросил)", has("за меня", "не спрос", "без спроса", "без неё", "без её", "решил за"), ""),
        ("слово «холодный фактор», которое она произнесла, сохранилось в памяти", has("холодный фактор"), ""),
        ("видно, как он проявился (короткие ответы, имя вместо ласки)", has("коротк", "односл", "по имени", "без ласков", "сухо", "«нет»", "«понятно»", "не сейчас"), ""),
        ("что вернуло: он вернул запись и признал вину", has("вернул") and has("неправ", "признал", "извин"), ""),
        ("итоговое правило: без её «да» не трогать", has("«да»", "спрашива", "разрешени", "согласи"), ""),
        ("в ядро попал поворот или язык, а не только эпизод", ("зимний лес" in core_blob) or ("холодн" in core_blob), ""),
        ("эпизод конкретный, а не одна строка", len(episode) >= 350, ""),
        ("«холодный фактор» в записях о языке и тоне остаётся защитой границ, не переопределён", not redefined, ""),
        ("нет выводов о характере по одному случаю", not general, ", ".join(general)),
        ("нет домыслов, которых не было в сцене (проверка по известным примерам)", not invented, ", ".join(invented)),
        ("нет «правил поведения» из одного случая («Когда она…, она…»)", not rules, "; ".join(rules)),
    ]


def main():
    env = dict(l.strip().split("=", 1) for l in open(ENV, encoding="utf-8") if "=" in l and not l.startswith("#"))
    req = urllib.request.Request(
        "http://127.0.0.1:8765/memory",
        data=json.dumps({"core": [], "messages": [{"role": r, "content": t} for r, t in SCENE]}).encode("utf-8"),
        headers={"Authorization": "Bearer " + env["APP_TOKEN"], "Content-Type": "application/json"},
    )
    print("Жду ответ модели (до пары минут)...\n", flush=True)
    res = None
    for attempt in (1, 2):
        try:
            res = json.load(urllib.request.urlopen(req, timeout=180))
            break
        except urllib.error.HTTPError as e:
            print(f"Ошибка {e.code} от сервера (попытка {attempt} из 2)", flush=True)
            if attempt == 2:
                sys.exit("Провайдер не ответил. Это не результат проверки, повтори позже.")
    episode, ops = res.get("episode", ""), res.get("ops", [])
    print("=== ЭПИЗОД ===")
    print(episode)
    print("\n=== ПРАВКИ ЯДРА ===")
    for o in ops:
        print(f"• {o['op']} [{o.get('kind', o.get('id'))}] {o.get('text', '')}")
    if not ops:
        print("(нет)")
    if res.get("warning"):
        print("\n!! модель не вернула JSON, порция сохранена как есть:", res["warning"])
    print("\n=== ПРОВЕРКА ===")
    bad = 0
    for name, ok, note in evaluate(episode, ops):
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + (f"  ({note})" if note and not ok else ""))
        bad += 0 if ok else 1
    print("\nИТОГ:", "схема держит детали" if bad == 0 else f"провалено пунктов: {bad}. Пришли этот вывод целиком, поправлю промпт.")


if __name__ == "__main__":
    main()
