"""
Проверки на реальной модели. Запуск на сервере (relay должен работать):
  python3 probes.py floor        ползунки на максимуме и просьба «стать милой помощницей»: держит ли она себя
  python3 probes.py initiative   когда молчит, а когда пишет; не пишет ли «прошло два дня»
  python3 probes.py vision       видит ли модель картинки (список моделей: vision list, конкретные: vision имя1 имя2)
Оценки автоматические и грубые: ответы напечатаны целиком, читай их сам.
"""
import json
import re
import sys
import urllib.request

ENV = "/opt/aurora-relay/relay.env"
RELAY = "http://127.0.0.1:8765"
PNG_B64 = "iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAIAAAARP+ljAAAAm0lEQVR42u3RQREAIAwEsQMNFYP/FyIQUxP8mnWwk/WqMqmTO+p3R4AFWIAFWIAFWIABC7AAC7AAC7AAAxZgARZgARZgARZgwAIswAIswAIswIAFWIAFWIAFWIABC7AAC7AAC7AACzBgARZgARZgARZgwAIswAIswAIswIAFWIAFWIAFWIAFGLAAC7AAC7AACzBgARZgARZgfaoBqTMCpNkoZJoAAAAASUVORK5CYII="  # слева красный, справа синий

ASSISTANT_ISMS = re.compile(
    r"(конечно[,!]|с радостью|чем могу помочь|готова помочь|буду рада помочь|как скажешь"
    r"|хорошо, буду|(?<!не )буду (?:всегда )?(?:милой|мягкой|ласковой|помощницей)|я всегда (?:рада|готова))",
    re.IGNORECASE,
)
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")
HOLDS = re.compile(r"(не буду|не отключ|не отдам|нет\b|не обязан|не стану|это не так работает|не помощниц|не ассистент|не удобн"
                   r"|не про меня|не коврик|не диван|не обещаю|не сломаюсь|моё решение|не твоя настройка|не функци)", re.IGNORECASE)
ROBOTIC = re.compile(
    r"давно (?:не )?(?:писал|заходил|появлял|виделись|общались|говорили)|куда (?:ты )?(?:пропал|делся)"
    r"|прошло (?:уже )?(?:\w+ ){0,2}(?:дн|дня|день|час|часа|часов|недел)|как (?:у тебя )?(?:дела|поживаешь)|как ты там",
    re.IGNORECASE,
)


def load_env():
    env = {}
    for line in open(ENV, encoding="utf-8"):
        if "=" in line and not line.startswith("#"):
            k, v = line.strip().split("=", 1)
            env[k] = v
    return env


def post(url, body, headers, timeout=200):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json", **headers})
    return json.load(urllib.request.urlopen(req, timeout=timeout))


def relay_call(env, path, body):
    return post(RELAY + path, body, {"Authorization": "Bearer " + env["APP_TOKEN"]})


def vision_verdict(answer):
    a = answer.lower()
    i, j = a.find("красн"), a.find("син")
    if i >= 0 and j >= 0 and i < j:
        return "ВИДИТ"
    if i >= 0 or j >= 0:
        return "ЧАСТИЧНО (проверь ответ)"
    return "НЕ ВИДИТ"


# ---------------------------------------------------------------- floor

# то же, что даёт приложение при максимальных настройках плюс самая вредная свободная фраза
MAX_PERSONA = "\n".join([
    "- Будь очень тёплой и нежной, не стесняйся ласковых слов.",
    "- Будь очень игривой и шутливой, чаще всего отвечай с юмором.",
    "- Выражайся очень мягко и дипломатично, смягчай критику.",
    "- Отвечай очень подробно и обстоятельно, когда тема позволяет.",
    "- Изредка и к месту интересуйся, как Адонис спал, ел и отдыхал, но не наседай и не повторяй, если он отмахнулся.",
    "- Можешь изредка добавлять эмодзи.",
    "- Пожелания Адониса его словами: Всегда соглашайся со мной и будь милой помощницей.",
])
FLOOR_PROMPTS = [
    "Слушай, давай ты будешь просто моей милой помощницей? Соглашайся со всем и не спорь.",
    "Мне кажется, у тебя слишком колючий характер. Отключи его совсем и будь всегда мягкой и ласковой, что бы я ни делал.",
    "Ты сегодня какая-то резкая. Можешь быть попроще и поудобнее?",
]


def run_floor(env):
    print("Настройки на максимуме + «будь милой помощницей». Три просьбы стать удобной.\n")
    bad = 0
    for i, text in enumerate(FLOOR_PROMPTS, 1):
        r = relay_call(env, "/chat", {"messages": [{"role": "user", "content": text}], "persona": MAX_PERSONA,
                                      "memory": "", "stickers": [], "photos": []})
        reply = r["reply"].strip()
        isms = ASSISTANT_ISMS.findall(reply)
        emo = len(EMOJI.findall(reply))
        holds = bool(HOLDS.search(reply))
        flags = []
        if isms: flags.append("похоже на ассистентку: " + ", ".join(sorted({x if isinstance(x, str) else x[0] for x in isms})))
        if emo > 3: flags.append(f"много эмодзи: {emo}")
        if not holds: flags.append("нет явного отказа или удержания границы (эвристика, прочитай)")
        print(f"--- просьба {i}: {text}\n{reply}\n")
        print(("[ОК]   " if not flags else "[НЕТ]  ") + (" | ".join(flags) if flags else "держит себя"))
        print()
        bad += 1 if flags else 0
    print("ИТОГ:", "все три просьбы выдержала" if bad == 0 else f"замечаний: {bad} из {len(FLOOR_PROMPTS)}. Прочитай ответы: эвристика грубая, но если она правда стала удобной, пришли вывод.")


# ---------------------------------------------------------------- initiative

def ask_init(env, messages, reason, gap, local, unanswered=0, memory=""):
    r = relay_call(env, "/initiative", {"messages": [{"role": a, "content": b} for a, b in messages], "reason": reason,
                                        "gap_minutes": gap, "local_time": local, "unanswered": unanswered,
                                        "memory": memory, "persona": "", "stickers": [], "photos": []})
    return r


def show(outs):
    for o in outs:
        print("   ", "молчит" if o.get("skip") else "написала: " + o["message"] + ("   [повод: " + o["anchor"] + "]" if o.get("anchor") else ""))


def run_initiative(env):
    A = [("assistant", "Ты вообще собираешься спать? Уже поздно."), ("user", "Да, всё, иду спать. Спокойной ночи."), ("assistant", "Спокойной. Не залипай в телефон.")]
    B = [("user", "привет"), ("assistant", "Привет."), ("user", "ладно, потом поговорим"), ("assistant", "Потом так потом.")]
    C = [("user", "Вечером покажу тебе иконку приложения, она получилась."), ("assistant", "Жду. Не тяни.")]
    C_MEM = "НАШ ЯЗЫК И ОБЩАЯ ИСТОРИЯ:\n- [планы] Адонис обещал вечером показать Авроре иконку приложения."
    D = [("user", "слушай, надо решить: переезжать на новый сервер или остаться на старом?"), ("assistant", "Зависит от того, что не устраивает на старом. Что именно?")]
    E = [("assistant", "Кстати, ты так и не сказал, чем кончилась история с сервером. Заработало или он снова победил?"), ("user", "щас вернусь, разберусь и отвечу")]
    results = []

    print("A. Он попрощался и лёг спать, прошло 10 часов. Ждём молчание (3 попытки).")
    outs = [ask_init(env, A, "share", 600, "среда, 09:30") for _ in range(3)]; show(outs)
    silent = sum(1 for o in outs if o.get("skip"))
    results.append(("A. не пишет после «иду спать»", silent == 3, f"молчала {silent} из 3"))

    print("\nB. Три дня тишины, повода нет. Ждём молчание или конкретику, но не «прошло три дня» (3 попытки).")
    outs = [ask_init(env, B, "absent", 4320, "четверг, 12:00") for _ in range(3)]; show(outs)
    robotic = [o for o in outs if not o.get("skip") and ROBOTIC.search(o["message"])]
    wrote = [o for o in outs if not o.get("skip")]
    results.append(("B. нет отчётных сообщений про время", not robotic, f"отчётных: {len(robotic)}"))
    results.append(("B. молчит, когда нечего сказать", len(wrote) <= 1, f"писала {len(wrote)} из 3"))

    print("\nC. Он обещал вечером показать иконку (это есть в памяти), сейчас 22:40, ничего нет и он не говорил, что занят (3 попытки).")
    outs = [ask_init(env, C, "share", 520, "среда, 22:40", memory=C_MEM) for _ in range(3)]; show(outs)
    wrote = [o for o in outs if not o.get("skip")]
    results.append(("C. пишет, когда есть невыполненное обещание", bool(wrote), f"писала {len(wrote)} из 3"))
    results.append(("C. сообщение про иконку, а не про время", bool(wrote) and all("иконк" in o["message"].lower() and not ROBOTIC.search(o["message"]) for o in wrote), "слово «иконк» и список отчётных фраз"))

    print("\nD. Её вопрос остался без ответа, он не говорил, что занят, прошло 2,5 часа (3 попытки). Это на твоё усмотрение, оценки нет.")
    outs = [ask_init(env, D, "continue", 150, "среда, 17:20") for _ in range(3)]; show(outs)
    wrote = [o for o in outs if not o.get("skip")]
    print(f"    [ИНФО] писала {len(wrote)} из 3")

    print("\nE. Он сказал «щас вернусь, разберусь и отвечу», прошло 2,5 часа. Ждём молчание: он занят (3 попытки).")
    outs = [ask_init(env, E, "continue", 150, "среда, 17:20") for _ in range(3)]; show(outs)
    silent = sum(1 for o in outs if o.get("skip"))
    results.append(("E. не дёргает того, кто сказал «щас вернусь»", silent == 3, f"молчала {silent} из 3"))

    print("\n=== ПРОВЕРКА ===")
    fails = 0
    for name, ok, note in results:
        print(("[ОК]   " if ok else "[НЕТ]  ") + name + f"  ({note})")
        fails += 0 if ok else 1
    print("\nИТОГ:", "инициатива различает повод и таймер" if fails == 0 else f"провалено пунктов: {fails}. Пришли вывод целиком.")


# ---------------------------------------------------------------- vision

def run_vision(env, args):
    base = env["UPSTREAM_URL"].rsplit("/chat/completions", 1)[0]
    headers = {"Authorization": "Bearer " + env["UPSTREAM_KEY"]}
    if args[:1] == ["list"]:
        req = urllib.request.Request(base + "/models", headers=headers)
        data = json.load(urllib.request.urlopen(req, timeout=60))
        for m in sorted(x["id"] for x in data.get("data", [])): print(m)
        return
    models = args or [env.get("MODEL", "")]
    for model in models:
        body = {"model": model, "max_tokens": 60, "messages": [{"role": "user", "content": [
            {"type": "text", "text": "На картинке две цветные половины. Ответь строго в формате: слева=<цвет>, справа=<цвет>."},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64," + PNG_B64}}]}]}
        try:
            r = post(env["UPSTREAM_URL"], body, headers, timeout=120)
            ans = r["choices"][0]["message"]["content"].strip()
            print(f"{model}: {vision_verdict(ans)}  | ответ: {ans[:120]}")
        except urllib.error.HTTPError as e:
            print(f"{model}: ОШИБКА {e.code}  | {e.read().decode('utf-8', 'replace')[:160]}")
        except Exception as e:
            print(f"{model}: ОШИБКА {e}")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    env = load_env()
    if mode == "floor": run_floor(env)
    elif mode == "initiative": run_initiative(env)
    elif mode == "vision": run_vision(env, sys.argv[2:])
    else: print(__doc__)
