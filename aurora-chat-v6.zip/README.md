# Аврора: версия 0.6 (Аврора видит твои фото)

## Сервер (Termux)
    Z=$(ls -t /storage/emulated/0/Download/aurora-chat-v6*.zip | head -1); echo "$Z"
    unzip -p "$Z" aurora-relay/relay.py > ~/relay.new; wc -c ~/relay.new
    [ -s ~/relay.new ] && scp ~/relay.new root@92.118.112.46:/opt/aurora-relay/relay.py && ssh root@92.118.112.46 "systemctl restart aurora-relay"

## Приложение
1. Загрузить zip в корень репозитория AuroraChat.
2. Actions → Unpack → Run workflow.
3. Actions → Build APK → Run workflow.
4. Установить поверх.
